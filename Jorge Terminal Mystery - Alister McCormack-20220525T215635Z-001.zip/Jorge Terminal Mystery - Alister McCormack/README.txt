 . . . . . . . . . . . . . . . . . . . .
 . . . . . . .@@@@@@@@@@@@@. . . . . . .
 · · · · · @@@@@@@@@@@@@@@@@@@ · · · · ·     
. . . . .@@@@@@@@@@@@@@@@@@@@@@@. . . . 
. . . . .@@@@@@@. . . . .@@@@@@@. . . . 
 . . . .,@@@@@@. . . . . @@@@@@@ . . . .
 . . . . . . . . . . . .@@@@@@@@ . . . .
. . . . . . . . . . .@@@@@@@@@. . . . . 
. . . . . . . . . @@@@@@@@  . . . . . . 
 . . . . . . . . .@@@@@@ . . . . . . . .
 . . . . . . . . . . . . . . . . . . . .
. . . . . . . . . @@@@@. . . . . . . . . 
. . . . . . . . .@@@@@@@ . . . . . . . . 
. . . . . . . . . @@@@@. . . . . . . . .
 
Ayudanos a encontrar la razón por la cual faltó Jorge Muñoz...

A lo largo de este mini-desafío, deberás aplicar los comandos
aprendidos para moverte entre las clases (carpetas/directorios)
e investigar al hablar con profesores del DCC.

No te preocupes si es que olvidaste los comando aprendidos...
Estos son los que tendrás que usar para resolver el misterio:

1) cd
2) ls 
3) cat

Para comenzar, dirigete a la faculatad de Economía y busca a 
Denis Parra

Pista: Economía está en "facultades/economia"

py key.py "key-1" "key-2" "key-3"